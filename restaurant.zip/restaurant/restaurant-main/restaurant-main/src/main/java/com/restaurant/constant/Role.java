package com.restaurant.constant;

public enum Role {
    USER, ADMIN
}
